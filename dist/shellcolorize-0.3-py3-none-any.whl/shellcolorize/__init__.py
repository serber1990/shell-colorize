#__init__.py
from .color import Color

# Export Color class to make it accessible as `shellcolorize.Color`
__all__ = ["Color"]
